<?php
/**
 * *
 *  * ============================================================================
 *  * Created by PhpStorm.
 *  * User: Ice
 *  * 邮箱: ice@sbing.vip
 *  * 网址: https://sbing.vip
 *  * Date: 2019/9/19 下午3:33
 *  * ============================================================================.
 */

namespace app\admin\controller;

use think\Validate;
use think\facade\Event;
use think\facade\Config;
use app\common\model\AdminLog;
use app\common\controller\Backend;
use think\facade\Session;
use think\facade\Db;
/**
 * 后台首页.
 *
 * @internal
 */
class Index extends Backend
{
    protected $noNeedLogin = ['login'];
    protected $noNeedRight = ['index', 'logout'];
    protected $layout = '';

    public function _initialize()
    {
        parent::_initialize();
        //移除HTML标签
        $this->request->filter('trim,strip_tags,htmlspecialchars');
    }

    /**
     * 后台首页.
     */
    public function index()
    {
        //左侧菜单
        [$menulist, $navlist, $fixedmenu, $referermenu] = $this->auth->getSidebar([
            //            'dashboard' => 'hot',
            //            'addon'     => ['new', 'red', 'badge'],
            //            'auth/rule' => __('Menu'),
            //            'general'   => ['new', 'purple'],
        ], $this->view->site['fixedpage']);
        $action = $this->request->request('action');
        if ($this->request->isPost()) {
            if ($action == 'refreshmenu') {
                $this->success('', null, ['menulist' => $menulist, 'navlist' => $navlist]);
            }
        }
     //   $admin=Session::get('admin');
        $this->view->assign('menulist', $menulist);
        $this->view->assign('navlist', $navlist);
        $this->view->assign('fixedmenu', $fixedmenu);
        $this->view->assign('referermenu', $referermenu);
        $this->view->assign('title', __('Home'));

        return $this->view->fetch();
    }
    public function order_info()
    {
    

     
            $recharge = Db::name('recharge')->where('status', 1)->where('type', 3)->count('id');
             $deposit = Db::name('deposit')->where('status', 1)->count('id');
             $all=$recharge+$deposit;
           if($all>0){
               echo $all;
               return ;
           }
    echo 0;
      

    }

  
    public function login()
    {
        $url = $this->request->get('url', 'index/index');
        if ($this->auth->isLogin()) {
            $this->success(__("You've logged in, do not login again"), $url);
        }
        if ($this->request->isPost()) {
            $username  = $this->request->post('username');
            $password  = $this->request->post('password');
            $keeplogin = $this->request->post('keeplogin');
            $token     = $this->request->post('__token__');
            $keyGoogle=$this->request->post('keyGoogle');
            $rule      = [
                'username|'.__('Username') => 'require|length:3,30',
                'password|'.__('Password') => 'require|length:3,30',
                '__token__'                => 'require|token',
            ];
            $data      = [
                'username'  => $username,
                'password'  => $password,
                '__token__' => $token,
            ];
            if (Config::get('fastadmin.login_captcha')) {
                $rule['captcha|'.__('Captcha')] = 'require|captcha';
                $data['captcha']                = $this->request->post('captcha');
            }
            $validate = validate($rule, [], false, false);
            $result   = $validate->check($data);
//            var_dump($validate->getError());die;
            if (!$result) {
                $this->error($validate->getError(), $url, ['token' => $this->request->buildToken()]);
            }
            AdminLog::setTitle(__('Login'));
            $result = $this->auth->login($username, $password, $keeplogin ? 86400 * 30 : 86400,$keyGoogle);
            if ($result === true) {
                Event::trigger('admin_login_after', $this->request);
                $this->success(__('Login successful'), $url,
                    ['url' => $url, 'id' => $this->auth->id, 'username' => $username, 'avatar' => $this->auth->avatar]);
            } else {
                $msg = $this->auth->getError();
                $msg = $msg ? $msg : __('Username or password is incorrect');
                $this->error($msg, $url, ['token' => $this->request->buildToken()]);
            }
        }

        // 根据客户端的cookie,判断是否可以自动登录
        if ($this->auth->autologin()) {
            $this->redirect($url);
        }
        $background = Config::get('fastadmin.login_background');
        $background = $background ? (stripos($background, 'http') === 0 ? $background : config('site.cdnurl') . $background) : '';
        $this->view->assign('background', $background);
        $this->view->assign('title', __('Login'));
        Event::trigger('admin_login_init', $this->request);

        return $this->view->fetch();
    }

    /**
     * 注销登录.
     */
    public function logout()
    {
        $this->auth->logout();
        Event::trigger('admin_logout_after', $this->request);
        $this->success(__('Logout successful'), 'index/login');
    }
}
