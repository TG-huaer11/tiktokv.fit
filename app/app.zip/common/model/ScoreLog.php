<?php

namespace app\common\model;

/**
 * 会员积分日志模型.
 */
class ScoreLog extends BaseModel
{
    // 表名
    protected $name = 'user_score_log';
    // 开启自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';
    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = false;
    // 追加属性
    protected $append = [
    ];
}
